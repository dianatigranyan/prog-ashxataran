@file:Suppress("UNUSED_LAMBDA_EXPRESSION")
import org.openrndr.Program
import org.openrndr.draw.*

{ program: Program ->
    program.apply {
        extend {

        }
    }
}