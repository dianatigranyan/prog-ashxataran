package examples

import org.openrndr.application
import org.openrndr.color.ColorRGBa
import org.openrndr.draw.ColorBuffer
import org.openrndr.draw.Filter
import org.openrndr.draw.FontImageMap
import org.openrndr.draw.filterShaderFromUrl
import org.openrndr.extra.compositor.*
import org.openrndr.filter.blend.Add
import org.openrndr.filter.blur.Blend
import org.openrndr.filter.blur.BoxBlur
import org.openrndr.filter.blur.DropShadow
import org.openrndr.math.Vector2
import org.openrndr.resourceUrl
import org.openrndr.workshop.toolkit.filters.*
import java.time.LocalDateTime

fun main() = application {


    configure {
        width = 600
        height = 800
    }

    program {

        val poster = compose {

            layer {
                post(BoxBlur())
                post(ZoomMosaic()) {
                    this.scale = Math.cos(seconds) * 2.0 + 3.0
                }
                draw {
                    drawer.fill = ColorRGBa.PINK
                    drawer.circle(width/2.0, height/2.0, 200.0)
                }
            }

            layer {

                draw {
                    val font = FontImageMap.fromUrl("file:data/fonts/Rumeur/rumeur.otf", 32.0)
                    drawer.fontMap = font
                    drawer.fill = ColorRGBa.BLUE
                    drawer.translate(10.0, 10.0)
                    drawer.text("poster for today:", 0.0, 100.0)
                }
            }
            layer {

                blend(Add())

                post(BoxBlur()) {
                    this.window = mouse.position.y.toInt()
                }
                post(Waves()) {
                    this.amplitude = 0.1
                    this.period = 10.0
                    this.phase = seconds
                }
                draw {
                    val font = FontImageMap.fromUrl("file:data/fonts/Rumeur/rumeur.otf", 96.0)
                    drawer.fontMap = font
                    drawer.fill = ColorRGBa.WHITE
                    val date = LocalDateTime.now()
                    drawer.translate(10.0, 10.0)
                    drawer.text("${date.dayOfWeek.name}", 0.0, 200.0)
                    drawer.text("${date.month.name} ${date.dayOfMonth}", 0.0, 280.0)
                    drawer.text("${date.year}", 0.0, 360.0)
                }
            }
        }

        extend {
            poster.draw(drawer)
        }
    }

}

