package poster.animations

import org.openrndr.color.ColorRGBa
import org.openrndr.draw.Drawer

fun animation1(drawer: Drawer, seconds: Double) {
    drawer.background(ColorRGBa(1.0, 0.5, 0.5))
    drawer.fill = ColorRGBa.WHITE
    drawer.stroke = ColorRGBa.BLACK
    drawer.strokeWeight = 5.0

    for (i in 0 until 16) {
        val x = Math.cos(i + seconds) * 40.0 + 40.0
        val r = Math.cos(i + seconds * 0.3) * 40.0 + 40.0
        drawer.circle(x + 40.0 + 40.0, 30 + i * 40.0, r)
    }
}

fun animation2(drawer: Drawer, seconds: Double) {
    drawer.background(ColorRGBa(1.0, 0.5, 0.5))
    drawer.fill = ColorRGBa.WHITE
    drawer.stroke = ColorRGBa.BLACK
    drawer.strokeWeight = 8.0


    for (i in 0 until 16) {
        val x = Math.cos(i + seconds) * 240.0
        val y = Math.sin(i + seconds) * 240.0

        val r = Math.cos(i + seconds * 0.3) * 40.0 + 40.0

        drawer.circle(x + drawer.width / 2.0, y + drawer.height / 2.0, r)

    }
}

fun animation3(drawer: Drawer, seconds: Double) {
    drawer.background(ColorRGBa(1.0, 0.1, 0.1))
    drawer.fill = ColorRGBa.RED
    drawer.stroke = ColorRGBa.YELLOW
    drawer.strokeWeight = 8.0


    for (i in 0 until 36) {
        val x = Math.cos(i + seconds) * 240.0
        val y = Math.sin(i + seconds) * 240.0

        val r = Math.cos(i + seconds * 0.3 * 0) * 40.0 + 40.0

        drawer.circle(x + drawer.width / 2.0, y + drawer.height / 2.0, r)


    }

}

fun animation6(drawer: Drawer, seconds: Double) {
    drawer.background(ColorRGBa(0.0, 0.0, 0.5))
    drawer.fill = ColorRGBa.WHITE
    drawer.stroke = ColorRGBa.BLACK
    drawer.strokeWeight = 8.0


    for (i in 0 until 16) {
        val x = Math.sin(i + seconds) * 40.0 + 40.0

        val r = Math.tan(i + seconds * 0.3) * 40.0 + 40.0

        drawer.circle(x + 40.0 + 40.0, 30 + i * 40.0, Math.abs(r))


    }


}

fun animation7(drawer: Drawer, seconds: Double) {
    drawer.background(ColorRGBa(0.0, 1.0, 0.0))
    drawer.fill = ColorRGBa.WHITE
    drawer.stroke = ColorRGBa.BLACK
    drawer.strokeWeight = 8.0


    for (i in 0 until 16) {
        val x = Math.tan(i + seconds) * 40.0 + 40.0

        val r = Math.tan(i + seconds * 0.3) * 40.0 + 40.0

        drawer.circle(x + 40.0 + 40.0, 30 + i * 40.0, Math.abs(r))


    }

}

fun animation8(drawer: Drawer, seconds: Double) {
    drawer.background(ColorRGBa(0.0, 0.0, 3.0))
    drawer.fill = ColorRGBa.WHITE
    drawer.stroke = ColorRGBa.BLACK
    drawer.strokeWeight = 8.0


    for (i in 0 until 16) {
        val x = Math.tan(i + seconds) * 240.0
        val y = Math.tan(i + seconds) * 240.0

        val r = Math.tan(i + seconds * 0.3) * 40.0 + 40.0

        drawer.circle(x + 40.0 + 40.0, 30 + i * 40.0, Math.abs(r))
    }
}

