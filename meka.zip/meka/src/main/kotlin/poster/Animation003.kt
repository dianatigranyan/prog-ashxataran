package poster

import org.openrndr.application
import org.openrndr.color.ColorRGBa

fun main() {
    application {

        configure {
            width = 600
            height = 800
        }
        program {
            extend {
                drawer.background(ColorRGBa(1.0, 0.1, 0.1))
                drawer.fill = ColorRGBa.RED
                drawer.stroke = ColorRGBa.YELLOW
                drawer.strokeWeight = 8.0


                for (i in 0 until 36) {
                    val x = Math.cos(i + seconds) * 240.0
                    val y = Math.sin(i + seconds) * 240.0

                    val r = Math.cos(i + seconds*0.3*0) * 40.0 + 40.0

                    drawer.circle(x + width/2.0, y + height/ 2.0, r)


                }


            }
        }
    }
}