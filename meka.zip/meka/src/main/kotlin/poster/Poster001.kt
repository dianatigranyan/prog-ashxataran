package examples

import jdk.nashorn.internal.objects.NativeJava.extend
import org.jetbrains.kotlin.js.dce.InputResource.Companion.file
import org.openrndr.animatable.Animatable
import org.openrndr.animatable.easing.Easing
import org.openrndr.application
import org.openrndr.color.ColorRGBa
import org.openrndr.configuration
import org.openrndr.draw.*
import org.openrndr.extra.compositor.*
import org.openrndr.extra.noclear.NoClear
import org.openrndr.filter.blend.Multiply
import org.openrndr.shape.Rectangle
import org.openrndr.text.Writer
import org.openrndr.workshop.toolkit.filters.ZoomMosaic
import poster.animations.*
import java.io.File

fun main() {
    application {

        configure {
            height = 1000
            width = 1000
            windowResizable = true


        }

        program {

            //----------------------------------------------Animation N1

            var imageColor = ColorRGBa.WHITE
            var scale = 1.0
            var clear = false

            class Brush : Animatable() {
                var scale = 1.0
                var rotation = 0.0
                var amplitude = 0.0
                var hi = 0.0


            }

            val brush = Brush()


            var animations = listOf(
                    ::animation1,
                    ::animation2,
                    ::animation3,
                    ::animation6,
                    ::animation7,
                    ::animation8

            )

            var animation = animations[0]

            keyboard.character.listen {

                if (it.character == 's') {
                    clear = true
                }
                if (it.character == 'k') {
                    brush.animate("amplitude",
                            Math.random() * 500.0,
                            1000,
                            Easing.CubicInOut)

                }

            }
            extend(NoClear())

            //---------------------------------------------------


            class Image(val image: ColorBuffer, val x: Double, val y: Double)

            val images = mutableListOf<Image>()
            val texts = mutableListOf<List<String>>()


            fun loadData() {
                val folderIndex = 1 + (Math.random() * 10.0).toInt()
                val folderFormat = String.format("%03d", folderIndex)
                val archive = File("data/archive/$folderFormat")

                images.clear()
                texts.clear()
                archive.listFiles().forEach {
                    if (it.extension == "jpg" || it.extension == "png") {
                        val imageData = loadImage(it)
                        val image = Image(imageData, Math.random() * (width - imageData.width), Math.random() * (height - imageData.height))
                        images.add(image)
                    }
                    if (it.extension == "txt") {
                        val txtData = it.readLines()
                        texts.add(txtData)
                    }
                }
                images.shuffle()
            }
            loadData()

            mouse.clicked.listen {
                imageColor = ColorRGBa(Math.random(), Math.random(), Math.random())
                animation = animations.random()
                loadData()
            }


            val poster = compose {

                layer {
                    clearColor = null
                    draw {
                        animation(drawer, seconds)
                    }
                }

                // -- images
                layer {
                    blend(Multiply())
                    draw {
//                        for (image in images) {
//                            drawer.image(image.image, image.x, image.y)
//                        }
                        drawer.image(images[0].image, 0.0, 0.0, width*1.0, height*1.0)
                    }
                }

                // -- body text
                layer {

                    draw {
                        for (text in texts) {
                            val w = Writer(drawer)

                            w.box = Rectangle(0.0, height/2.0, width / 2.0, height/2.0)

                            val font = FontImageMap.fromUrl("file:data/fonts/_3270/3270Medium.ttf", 16.0)
                            drawer.fontMap = font

                            for (line in text) {
                                w.newLine()
                                w.text(line)
                            }
                        }
                    }
                }

                // -- title
                layer {
                    draw {
                        for (text in texts) {
                            val w = Writer(drawer)
                            val font = FontImageMap.fromUrl("file:data/fonts/_3270/3270Medium.ttf", 128.0)
                            drawer.fontMap = font
                            val title = text[0]
                            w.newLine()
                            w.text(title)
                        }
                    }

                }
            }
            extend {
                poster.draw(drawer)

                //-------------------------Animation N1


            }
        }

    }
}

