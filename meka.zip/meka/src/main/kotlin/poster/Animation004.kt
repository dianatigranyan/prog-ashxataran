package poster

import org.openrndr.animatable.Animatable
import org.openrndr.application

fun main() {

    application {

        configure {
            width = 600
            height = 800
        }

        program {
            class A : Animatable() {
                var x: Double = 0.0
                var y: Double = 0.0
                var radius: Double = 0.0

                fun next() {
                    updateAnimation()
                    if (!hasAnimations()) {
                        var tx = Math.random() * width
                        var ty = Math.random() * height
                        val tr = Math.random() * 100.0
                        animate("x", tx, 1000)
                        animate("y", ty, 1000)
                        animate("radius", tr, 1000)
                    }
                }
            }

            val circles = mutableListOf<A>()


            for (i in 0 until 16) {
                circles.add(A())
            }



            extend {

                for (a in circles) {
                    a.next()
                    drawer.circle(a.x, a.y, a.radius)
                }
            }

        }
    }
}