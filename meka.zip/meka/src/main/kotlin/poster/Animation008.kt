package poster



import org.openrndr.application
import org.openrndr.color.ColorRGBa

fun main() {
    application {

        configure {
            width = 600
            height = 800
        }

        program {
            extend {
                drawer.background(ColorRGBa(0.0, 0.0, 3.0))
                drawer.fill = ColorRGBa.WHITE
                drawer.stroke = ColorRGBa.BLACK
                drawer.strokeWeight = 8.0


                for (i in 0 until 16) {
                    val x = Math.tan(i + seconds) * 240.0
                    val y = Math.tan(i + seconds) * 240.0

                    val r = Math.tan(i + seconds*0.3) * 40.0 + 40.0

                    drawer.circle(x + width/2.0, y + height/ 2.0, Math.abs(r))


                }


            }
        }
    }
}