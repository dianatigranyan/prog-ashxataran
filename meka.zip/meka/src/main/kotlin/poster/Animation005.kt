package poster

import org.openrndr.animatable.Animatable
import org.openrndr.application
import org.openrndr.draw.ColorBuffer
import org.openrndr.draw.FontImageMap
import org.openrndr.draw.loadImage

fun main() {

    application {

        configure {
            width = 800
            height = 800
        }

        program {
            class A(val image: ColorBuffer) : Animatable() {
                var x: Double = 0.0
                var y: Double = 0.0
                var radius: Double = 0.0

                fun next() {
                    updateAnimation()
                    if (!hasAnimations()) {
                        var tx = Math.random() * (width-image.width)
                        var ty = Math.random() * (height-image.height)
                        val tr = Math.random() * 100.0
                        animate("x", tx, 1000)
                        animate("y", ty, 1000)
                        animate("radius", tr, 1000)
                    }
                }
            }

            val balls = mutableListOf<A>()




            val images = listOf(
                    loadImage("data/archive/001/3284e696c76c5bbbb0a9b227e8c97bd4d97b0b86.png"),
                    loadImage("data/archive/001/1496207953.jpg"),
                    loadImage("data/archive/001/images.jpeg")



            )


            for (i in 0 until 3) {
                balls.add(A(images[i%images.size]))
            }

            val font = FontImageMap.fromUrl("file:data/fonts/IBMPlexMono-Regular.ttf", 32.0)

            extend {
                var index = 0
                for (a in balls) {
                    a.next()
                    //drawer.circle(a.x, a.y, a.radius)

                    //drawer.rectangle(a.x, a.y, a.radius, a.radius)
                    drawer.fontMap = font
                    //drawer.text("photo", a.x, a.y)
                    drawer.image(a.image, a.x, a.y)
                    index++
                }
            }
        }
    }

}