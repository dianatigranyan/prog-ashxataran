package poster

import org.openrndr.application
import org.openrndr.color.ColorRGBa



fun main() {
    application {

        configure {
            width = 600
            height = 800
        }
        program {
            extend {
                drawer.background(ColorRGBa(0.0, 1.0, 0.0))
                drawer.fill = ColorRGBa.WHITE
                drawer.stroke = ColorRGBa.BLACK
                drawer.strokeWeight = 8.0


                for (i in 0 until 16) {
                    val x = Math.tan (i + seconds) * 40.0 + 40.0

                    val r = Math.tan(i + seconds*0.3) * 40.0 + 40.0

                    drawer.circle(x + 40.0 + 40.0, 30 + i * 40.0, Math.abs(r))


                }


            }
        }
    }
}