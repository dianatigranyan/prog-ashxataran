# Rumeur
 Rumeur is a font designed by groupe CCC (Alice Gavin & Valentin Bigel) in 2011 for theater company Compagnie La Rumeur based in Choisy-le-Roi.

##Specimen
![gbodywork1](https://rawgit.com/groupeccc/Rumeur/master/documentation/rumeur.svg)

## License

Rumeur is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at
http://scripts.sil.org/OFL

